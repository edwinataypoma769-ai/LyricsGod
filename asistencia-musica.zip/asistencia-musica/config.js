// Pega aquí tus credenciales de Supabase (Project Settings > API)
window.SUPABASE_URL = "PEGA_AQUI_TU_PROJECT_URL";
window.SUPABASE_ANON_KEY = "PEGA_AQUI_TU_ANON_PUBLIC_KEY";
